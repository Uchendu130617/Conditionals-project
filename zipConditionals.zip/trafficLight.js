let userColor = prompt("Enter a color");

if (userColor === "red") {
 alert(`Stop`);
 console.log(`Stop`);
}

else if (userColor === "yellow") {
    alert(`Slow down`);
    console.log("Slow down");
}

else if (userColor === "green") {
    alert(`Go`);
    console.log(`Go`);
}

else {
    alert(`Invalid color`);
    console.log(`Invalid color`);
}
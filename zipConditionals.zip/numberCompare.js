
let firstNumber = prompt("Enter a number");
let secondNumber = prompt("Enter another number");

if (firstNumber < secondNumber) {
    alert(`Second number is greater`);
    console.log(`Second number is greater`);
}

else if (firstNumber > secondNumber) {
    alert(`First number is greater`);
    console.log(`First number is greater`);
}

else if (firstNumber === secondNumber) {
    alert(`The numbers are equal`);
    console.log(`The numbers are equal`);
}

else {
    alert(`Invalid number`);
    console.log(`Invalid`);
}